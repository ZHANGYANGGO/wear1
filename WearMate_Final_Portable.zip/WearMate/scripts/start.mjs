import { execFile, spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const port = Number(process.argv[2] ?? 4199);
if (!Number.isInteger(port) || port < 1024 || port > 65535) {
  console.error('Choose a port between 1024 and 65535.');
  process.exit(1);
}

const root = fileURLToPath(new URL('../', import.meta.url));
const script = fileURLToPath(new URL('serve.mjs', import.meta.url));
const address = 'http://127.0.0.1:' + port + '/';
const server = spawn(process.execPath, [script,String(port)], {cwd:root,stdio:['ignore','pipe','inherit']});
let banner = '';
let started = false;
server.stdout.on('data', chunk => {
  process.stdout.write(chunk);
  if (started) return;
  banner += chunk.toString();
  if (!banner.includes(address)) return;
  started = true;
  if (process.platform === 'win32' && process.env.WEARMATE_NO_BROWSER !== '1') {
    execFile('rundll32.exe', ['url.dll,FileProtocolHandler',address], error => {
      if (error) console.log('Open the address above in your browser.');
    });
  }
});
server.on('error', error => { console.error(error.message); process.exitCode = 1; });
server.on('exit', code => { process.exitCode = code ?? 0; });
process.on('SIGINT', () => server.kill());
