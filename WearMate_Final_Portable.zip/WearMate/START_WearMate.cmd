@echo off
setlocal
cd /d "%~dp0"
set "WEARMATE_NODE=%~dp0runtime\node.exe"
if not exist "%WEARMATE_NODE%" set "WEARMATE_NODE=node"
"%WEARMATE_NODE%" "%~dp0scripts\start.mjs" %*
if errorlevel 1 pause
