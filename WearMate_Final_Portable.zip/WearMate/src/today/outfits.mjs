import { bobId } from '../wardrobe/woman-bob-wardrobe.mjs';

const asset = file => './assets/outfits/woman-bob/' + file + '.webp';
export const basePortrait = asset('avatar-base');
export function portraitFor(id) {
  if (id === bobId) return basePortrait;
  return ['man-smile', 'man-glasses', 'woman-silver'].includes(id)
    ? './assets/outfits/portraits/' + id + '.webp' : '';
}
const baseLayer = '米色打底为分身自带内搭';
export const scenes = ['日常出行', '上班通勤', '约会聚会', '运动休闲'];
const [daily, work, date, sport] = scenes;
const warmSeason = ['spring', 'summer', 'autumn'];
const coolSeason = ['spring', 'autumn'];
const winter = ['winter'];

const entries = [
  ['01', '海蓝舒适日常', ['navy-shirt', 'gray-joggers', 'white-platform-sneakers'], true, warmSeason, ['休闲', '运动'], [daily,sport], [15,29], 2],
  ['02', '深蓝利落通勤', ['navy-shirt', 'black-trousers', 'ivory-mary-janes'], true, warmSeason, ['通勤', '利落'], [work,daily], [16,32], 2],
  ['03', '蓝衫叠穿碎花', ['navy-shirt', 'floral-maxi', 'ivory-mary-janes'], false, warmSeason, ['约会', '轻叠穿'], [date,daily], [17,28], 2],
  ['04', '碎花轻裙', ['floral-maxi', 'ivory-mary-janes'], false, ['spring','summer'], ['约会','轻盈'], [date,daily], [20,34], 1],
  ['05', '暖白牛仔', ['white-puffer', 'light-blue-jeans', 'white-platform-sneakers'], true, winter, ['休闲','保暖'], [daily,sport], [1,15], 3],
  ['06', '紫调牛仔日常', ['purple-graphic-tee','light-blue-jeans','white-platform-sneakers'], false, warmSeason, ['休闲','复古'], [daily], [17,32], 1],
  ['07', '暖白紫调叠穿', ['white-puffer','purple-graphic-tee','black-trousers','ivory-mary-janes'], false, winter, ['通勤','保暖'], [work,daily], [4,15], 3],
  ['08', '紫调运动休闲', ['purple-graphic-tee','gray-joggers','white-platform-sneakers'], false, warmSeason, ['运动','休闲'], [sport,daily], [16,32], 1],
  ['09', '白衫学院百褶', ['white-long-sleeve-shirt','gray-pleated-skirt','brown-gold-buckle-loafers'], false, coolSeason, ['通勤','学院'], [work,date], [17,27], 1],
  ['10', '奶黄轻装', ['yellow-basic-tee','white-casual-shorts','white-platform-sneakers'], false, ['summer'], ['休闲','运动'], [daily,sport], [23,36], 1],
  ['11', '酒红复古通勤', ['burgundy-v-neck-knit','black-trousers','brown-gold-buckle-loafers'], false, coolSeason, ['通勤','复古'], [work,date], [14,24], 2],
  ['12', '绿意碎花', ['green-knit-cardigan','floral-maxi','ivory-mary-janes'], false, coolSeason, ['约会','轻叠穿'], [date,daily], [15,24], 2],
  ['13', '卡其白衫通勤', ['khaki-trench-coat','white-long-sleeve-shirt','black-trousers','brown-gold-buckle-loafers'], false, coolSeason, ['通勤','轻叠穿'], [work], [12,22], 2],
  ['14', '奶黄冬日通勤', ['yellow-hooded-jacket','white-long-sleeve-shirt','black-trousers','black-lace-up-boots'], false, winter, ['通勤','保暖'], [work,daily], [0,14], 3],
  ['15', '奶黄酒红牛仔', ['yellow-hooded-jacket','burgundy-v-neck-knit','light-blue-jeans','black-lace-up-boots'], false, winter, ['休闲','复古'], [daily,date], [-3,13], 3],
  ['16', '暖白运动叠穿', ['white-puffer','purple-graphic-tee','gray-joggers','white-platform-sneakers'], false, winter, ['运动','保暖'], [sport,daily], [1,14], 3],
  ['17', '紫调周末短裤', ['purple-graphic-tee','white-casual-shorts','white-platform-sneakers'], false, ['summer'], ['休闲','运动'], [daily,sport], [23,36], 1],
  ['18', '卡其酒红叠穿', ['khaki-trench-coat','burgundy-v-neck-knit','black-trousers','black-lace-up-boots'], false, coolSeason, ['通勤','复古'], [work,date], [12,21], 2],
  ['19', '奶黄运动叠穿', ['yellow-hooded-jacket','yellow-basic-tee','gray-joggers','white-platform-sneakers'], false, winter, ['运动','休闲'], [sport,daily], [2,15], 3],
  ['20', '暖白酒红牛仔', ['white-puffer','burgundy-v-neck-knit','light-blue-jeans','black-lace-up-boots'], false, winter, ['复古','保暖'], [date,daily], [-3,13], 3],
  ['21', '奶黄学院百褶', ['yellow-basic-tee','gray-pleated-skirt','ivory-mary-janes'], false, ['spring','summer'], ['约会','学院'], [date,daily], [22,34], 1],
  ['22', '白衫水洗牛仔', ['white-long-sleeve-shirt','light-blue-jeans','brown-gold-buckle-loafers'], false, warmSeason, ['通勤','休闲'], [work,daily], [16,27], 2],
  ['23', '青绿针织牛仔', ['green-knit-cardigan','light-blue-jeans','white-platform-sneakers'], true, coolSeason, ['休闲','轻叠穿'], [daily,date], [14,24], 2],
  ['24', '酒红百褶与短靴', ['burgundy-v-neck-knit','gray-pleated-skirt','black-lace-up-boots'], false, coolSeason, ['约会','复古'], [date,work], [15,24], 2],
];

export const outfitLibrary = entries.map(([
  number, name, garmentIds, hasBaseLayer, seasons, styleTags, scenes, temperatureRange, warmth,
]) => ({
  id: 'look-' + number, avatarId: bobId, name, garmentIds,
  image: asset('v24/look-' + number), thumbnail: asset('v24/look-' + number + '-thumb'),
  baseLayer: hasBaseLayer ? baseLayer : '',
  seasons, styleTags, scenes, temperatureRange, warmth,
  weather: {
    closedShoes: !garmentIds.includes('ivory-mary-janes'),
    outerLayer: warmth === 3 || garmentIds.includes('khaki-trench-coat') || garmentIds.includes('green-knit-cardigan'),
    skirt: garmentIds.some(id => id === 'floral-maxi' || id === 'gray-pleated-skirt'),
    shorts: garmentIds.includes('white-casual-shorts'),
  },
  enabled: true, recommendable: true, saveable: true,
}));

export function outfitsFor(avatarId, garmentId) {
  return outfitLibrary.filter(outfit => outfit.avatarId === avatarId && outfit.enabled
    && (!garmentId || outfit.garmentIds.includes(garmentId)));
}

export function availableOutfit(outfit, byId) {
  return outfit.garmentIds.every(id => byId.get(id)?.availability === 'available');
}

export function selectOutfits(avatarId, wardrobe, forecast, hasImage = () => true, scene = scenes[0]) {
  const byId = new Map(wardrobe.map(item => [item.id, item]));
  const feels = forecast.feels ?? forecast.temp;
  const effective = .65 * feels + .35 * forecast.temp;
  const cold = Math.min(feels, forecast.temp) < 12;
  const hot = Math.max(feels, forecast.temp) >= 27;
  const wet = forecast.rain >= 55 || (forecast.code >= 51 && forecast.code <= 99);
  const windy = forecast.wind >= 25;
  const month = Number(forecast.time?.slice(5,7));
  const season = month >= 3 && month <= 5 ? 'spring' : month >= 6 && month <= 8 ? 'summer'
    : month >= 9 && month <= 11 ? 'autumn' : 'winter';
  const ranked = outfitsFor(avatarId).flatMap(outfit => {
    if (!outfit.recommendable || !availableOutfit(outfit, byId) || !hasImage(outfit)) return [];
    const { weather, warmth, temperatureRange: [low, high] } = outfit;
    if (effective < low || effective > high || (cold && warmth < 3)
      || (hot && weather.outerLayer) || (windy && wet && (weather.skirt || weather.shorts))) return [];
    const items = outfit.garmentIds.map(id => byId.get(id));
    const tags = new Set(items.flatMap(item => item.styleTags ?? []));
    const coverage = weather.closedShoes;
    const sceneMatch = outfit.scenes.includes(scene);
    const score = 24 - Math.abs(effective - (low + high) / 2) * .65
      + Number(hot && warmth === 1) * 3 + Number(hot && (weather.skirt || weather.shorts)) * 4
      + Number(wet && coverage) * 7 - Number(wet && (weather.skirt || weather.shorts)) * 5
      + Number(windy && weather.outerLayer) * 4 - Number(windy && weather.skirt) * 3
      + Number(outfit.seasons.includes(season)) * 1.5 + Number(sceneMatch) * 4
      + Number(outfit.scenes[0] === scene) * 3
      + outfit.styleTags.filter(tag => tags.has(tag)).length * .5;
    const reason = warmth === 3 ? '含保暖外套，适合体感偏冷时叠穿。'
      : hot && warmth === 1 ? '轻装为主，适合较热的天气。'
        : '厚度适合当前体感。';
    const detail = wet && coverage ? '鞋面覆盖较多，遇雨仍需留意积水。'
      : wet ? '鞋面较开放，雨天适合较短的室外行程。'
        : windy && weather.outerLayer ? '风较大时可利用现有外层。' : '';
    return [{ ...outfit, items, score, reason: reason + detail + (sceneMatch ? '适合' + scene + '。' : '') }];
  });
  const result = [];
  while (ranked.length && result.length < 3) {
    const adjusted = plan => plan.score - Math.max(0, ...result.map(chosen =>
      plan.garmentIds.filter(id => chosen.garmentIds.includes(id)).length * .90
      + Number(plan.styleTags[0] === chosen.styleTags[0]) * 3));
    ranked.sort((a, b) => adjusted(b) - adjusted(a) || a.id.localeCompare(b.id));
    result.push(ranked.shift());
  }
  return { plans: result, cold, eligible: ranked.length + result.length };
}
