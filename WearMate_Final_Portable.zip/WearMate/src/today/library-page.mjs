import { localRegistration, readConfirmedProfile } from '../create/profiles.mjs';
import { openPersonalWardrobe } from '../wardrobe/personal.mjs';
import { bobId } from '../wardrobe/woman-bob-wardrobe.mjs';
import { availableOutfit, outfitsFor, portraitFor, scenes, selectOutfits } from './outfits.mjs';
import { cities, forecast, scenarios, simulated } from './weather.mjs';

const $ = id => document.getElementById(id);
const url = new URL(location.href);
if (url.searchParams.get('view') === 'all') {
  url.searchParams.set('view', 'today');
  window.history.replaceState(window.history.state, '', url);
}
const profileId = readConfirmedProfile()?.id ?? bobId;
const role = localRegistration.find(record => record.id === profileId);
const roleOutfits = outfitsFor(profileId);
const selectionKey = 'wearmate.v24.selected.' + profileId;
const prefKey = 'wearmate.today.weather';
const letters = ['A', 'B', 'C'];
const cityControl = $('weather-city');
const mode = $('weather-mode');
const scene = $('outfit-scene');
const cards = $('weather-plans');
let portrait = $('outfit-image');
let selected, activeId, weather, weatherRequest;
let imageSequence = 0;
const loaded = new Set();
let storage;
try { storage = localStorage; activeId = sessionStorage.getItem(selectionKey); } catch {}
const { store, key } = openPersonalWardrobe(storage, profileId);

function node(tag, text = '', className = '') {
  const element = document.createElement(tag);
  element.textContent = text;
  element.className = className;
  return element;
}

function picture(src, alt, lazy = false) {
  const image = node('img');
  image.alt = alt;
  image.decoding = 'async';
  if (lazy) image.loading = 'lazy';
  image.src = src;
  return image;
}

function closet() {
  try { return new Map(store.list().map(item => [item.id, item])); }
  catch { return null; }
}

function pieces(items) {
  const group = node('div', '', 'plan-pieces');
  for (const item of items) {
    const figure = node('figure');
    figure.dataset.garment = item.id;
    figure.append(picture(item.cartoonDisplayImage, '', true), node('figcaption', item.name));
    group.append(figure);
  }
  return group;
}

function setActive(id) {
  activeId = id;
  try { sessionStorage.setItem(selectionKey, id); } catch {}
}

function updateSelection() {
  for (const button of document.querySelectorAll('[data-select-plan]')) {
    const id = button.dataset.selectPlan;
    const highlighted = selected?.id === id;
    button.setAttribute('aria-pressed', String(highlighted));
    button.textContent = highlighted ? '正在展示' : '查看效果';
  }
}

async function show(plan, { use = false } = {}) {
  const token = ++imageSequence;
  const src = plan?.image ?? portraitFor(profileId);
  const image = portrait.cloneNode(false);
  image.alt = [role?.label, plan?.name ?? '基础分身'].filter(Boolean).join(' · ');
  const feedback = $('plan-feedback');
  if (src) {
    image.src = src;
    try { await image.decode(); }
    catch {
      if (token !== imageSequence) return false;
      if (plan) loaded.delete(plan.id);
      feedback.textContent = '此穿搭图片暂不可用，请选择其他方案。';
      updateSelection();
      if (portrait.hidden) {
        $('outfit-image-status').textContent = '图片暂不可用。';
        $('outfit-image-status').hidden = false;
      }
      return false;
    }
  }
  if (token !== imageSequence) return false;
  if (use && plan) setActive(plan.id);
  image.hidden = !src;
  portrait.replaceWith(image);
  portrait = image;
  $('outfit-image-status').textContent = '此分身暂无预览图。';
  $('outfit-image-status').hidden = Boolean(src);
  const items = plan?.items ?? [];
  selected = plan;
  $('look-name').textContent = plan?.name ?? '分身预览';
  $('look-details').textContent = items.map(item => item.name).join(' · ');
  feedback.textContent = plan?.baseLayer ?? '';
  updateSelection();
  return true;
}

function action(plan, text) {
  const button = node('button', text, 'look-action');
  button.type = 'button';
  button.dataset.selectPlan = plan.id;
  button.onclick = async () => {
    const wardrobe = closet();
    if (!wardrobe || !availableOutfit(plan, wardrobe)) {
      await renderPlans();
      $('plan-feedback').textContent = '衣柜状态有变，推荐已更新。';
      return;
    }
    if (await show(plan, {use:true})) {
      if (matchMedia('(max-width: 52rem)').matches) $('fitting-room').scrollIntoView({block:'start'});
    } else if (!loaded.has(plan.id)) {
      await renderPlans({keep:true});
      $('plan-feedback').textContent = '图片暂不可用，已更新推荐。';
    }
  };
  return button;
}

function outfitCard(plan, letter) {
  const card = node('article', '', 'plan-card');
  card.dataset.plan = plan.id;
  card.dataset.letter = letter;
  const header = node('header');
  header.append(node('span', letter, 'plan-letter'), node('h3', plan.name), action(plan, '查看效果'));
  const content = node('div', '', 'recommendation-body');
  content.append(picture(plan.thumbnail, plan.name, true), pieces(plan.items));
  card.append(header, content, node('p', plan.reason, 'plan-reason'));
  if (plan.baseLayer) card.append(node('p', plan.baseLayer, 'plan-base'));
  return card;
}

async function renderPlans({keep = false, reset = false} = {}) {
  cards.replaceChildren();
  const notes = $('weather-notes');
  notes.textContent = '';
  const wardrobe = closet();
  if (!roleOutfits.length) notes.textContent = '此分身暂无对应穿搭方案。';
  else if (!wardrobe) notes.textContent = '无法读取衣柜，请检查浏览器存储。';
  else if (weather) {
    const { plans, eligible } = selectOutfits(profileId, [...wardrobe.values()], weather, plan => loaded.has(plan.id), scene.value);
    cards.append(...plans.map((plan, index) => outfitCard(plan, letters[index])));
    const text = eligible < 3 ? '有效候选 ' + eligible + ' 套。' : '从 ' + eligible + ' 套有效候选中推荐 3 套。';
    notes.textContent = text + (loaded.size < roleOutfits.length ? ' 部分穿搭图片无法加载。' : '');
    if (plans.length < 3) {
      const empty = node('article', '', 'plan-card plan-empty');
      empty.append(node('strong', '适合当前条件的完整穿搭有限'));
      cards.append(empty);
    }
    const preferredId = keep ? selected?.id : activeId;
    const current = (reset ? null : plans.find(plan => plan.id === preferredId)) ?? plans[0];
    if (!(await show(current)) && current && !loaded.has(current.id)) {
      const fallback = plans.find(plan => loaded.has(plan.id));
      if (fallback) await show(fallback);
    }
    return;
  }
  if (!selected) await show();
}

function paint(w) {
  $('weather-degree').textContent = Math.round(w.temp) + '°';
  $('weather-condition').textContent = w.city.name + ' · ' + w.label;
  $('weather-range').textContent = '低 ' + w.low + '° / 高 ' + w.high + '°';
  $('weather-values').textContent = '体感 ' + (w.feels === null ? '暂无' : w.feels + '°C')
    + '　·　降水概率 ' + w.rain + '%　·　风速 ' + w.wind + ' km/h';
  const feels = w.feels ?? w.temp;
  $('weather-hint').textContent = feels < 12 ? '体感偏冷，优先考虑保暖外套。'
    : w.rain >= 55 ? '留意降水和积水，优先选择鞋面覆盖较多的搭配。'
      : feels >= 27 ? '体感偏热，适合轻薄搭配。'
        : w.wind >= 25 ? '风较大，外出可考虑有外层的搭配。' : '温度适宜，适合轻装出行。';
  $('weather-source').textContent = w.source + ' · ' + w.time.replace('T', ' ') + '　' + w.city.timezone;
  $('weather-summary').hidden = false;
}

$('stage-role-name').textContent = role?.label ?? '当前分身';
$('stage-role-type').textContent = '本地预制';
for (const city of cities) cityControl.add(new Option(city.name, city.name));
for (const [id, [label, temp]] of Object.entries(scenarios)) mode.add(new Option('模拟 · ' + temp + '°C ' + label, id));
for (const option of scenes) scene.add(new Option(option, option));
try {
  const prefs = JSON.parse(sessionStorage.getItem(prefKey));
  if (cities.some(city => city.name === prefs?.city)) cityControl.value = prefs.city;
  if (Object.hasOwn(scenarios, prefs?.mode)) mode.value = prefs.mode;
  if (scenes.includes(prefs?.scene)) scene.value = prefs.scene;
} catch {}
const saveWeatherPrefs = () => {
  try { sessionStorage.setItem(prefKey, JSON.stringify({ city:cityControl.value, mode:mode.value, scene:scene.value })); }
  catch {}
};
const images = Promise.all(roleOutfits.map(async plan => {
  try {
    const image = picture(plan.image,'');
    await image.decode();
    if (image.naturalWidth === 1024 && image.naturalHeight === 1536) loaded.add(plan.id);
  } catch {}
}));
async function refreshWeather(reset = false) {
  weatherRequest?.abort();
  const request = new AbortController();
  weatherRequest = request;
  const city = cities.find(entry => entry.name === cityControl.value);
  const live = mode.value === 'live';
  saveWeatherPrefs();
  $('weather-retry').hidden = !live;
  $('weather-summary').hidden = true;
  $('weather-status').textContent = live ? '正在获取' + city.name + '的当地天气…' : '';
  weather = null;
  await renderPlans();
  if (weatherRequest !== request) return;
  const timer = setTimeout(() => request.abort(),10000);
  try {
    const next = live ? await forecast(city,request.signal) : simulated(city,mode.value);
    await images;
    if (weatherRequest !== request) return;
    weather = next;
    $('weather-status').textContent = '';
    paint(next);
    await renderPlans({reset});
  } catch (error) {
    if (weatherRequest !== request) return;
    $('weather-status').textContent = '天气获取失败。' + (error.name === 'AbortError' ? '请求超时。' : '')
      + '请重试或选择模拟天气。';
  } finally { clearTimeout(timer); }
}
cityControl.onchange = mode.onchange = $('weather-retry').onclick = () => refreshWeather(true);
scene.onchange = () => { saveWeatherPrefs(); renderPlans({reset:true}); };
refreshWeather();

window.addEventListener('storage', event => {
  if (event.key === key || event.key === null) {
    renderPlans({keep:true});
  }
});
window.addEventListener('pageshow', event => {
  if (!event.persisted) return;
  try { activeId = sessionStorage.getItem(selectionKey); } catch {}
  renderPlans();
});
